const User = require('../models/user');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

const login = async (req, res) => {
    const {user, password} = req.body;

    if (!user || !password) return res.status(400).json({ 'message' : 'Email and password are required.'});
    const registeredUser = await User.findOne({ where: {email : user}});
    
    if (!registeredUser) return res.sendStatus(401);
    const found = await bcrypt.compare(password, registeredUser.password);
    
    if (found) {
        const role = registeredUser.role;
        const id = registeredUser.id;

        const accessToken = jwt.sign(
            {'email': registeredUser.email},
            process.env.ACCESS_TOKEN_SECRET,
            { expiresIn: '300s'}
        );
        
        const refreshToken = jwt.sign(
            {'email': registeredUser.email},
            process.env.REFRESH_TOKEN_SECRET,
            { expiresIn: '1d'}
        );
        
        registeredUser.refreshToken = refreshToken;
        const result = await registeredUser.save();
        console.log(result);

        res.cookie('jwt', refreshToken, { httpOnly: true, secure: true, sameSite: 'None', maxAge: 24 * 60 * 60 * 1000 });

        res.json({  id, role, accessToken });    
        
    } else {
         
        res.sendStatus(401);    
    }
}

module.exports = {login};
const User = require('../models/user');
const bcrypt = require('bcryptjs');

const newUser = async (req, res) => {
    const { username, email, password } = req.body;
    if (!username || !password || !email) return res.status(400).json({ 'message': 'Username, email and password are required'});
    if (await User.findOne({where: {username: username}})) return res.sendStatus(409);
    if (await User.findOne({where: {email: email}})) return res.sendStatus(409);
    
    try {
        const hashedPass = await bcrypt.hash(password, 10);
        const user = await User.create({
            username,
            email,
            password: hashedPass
        });

        console.log(user);
        res.status(201).json({ 'success': `New user ${user.username} created!` });
    } catch (err) {
        res.status(500).json({'message': err.message});
    }
}

module.exports = { newUser };
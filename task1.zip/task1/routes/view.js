const express = require('express');
const router = express.Router();
const viewController = require('../controllers/view')
const verify = require('../middleware/verifyJWT')

router.route('/').get(verify.verifyJWT, viewController.view);

module.exports = router;
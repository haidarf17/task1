require("dotenv").config();
const express = require('express');
const session = require('express-session');
const app = express();
const PORT = process.env.PORT || 3030;
const cookieParser = require('cookie-parser');

app.use(cookieParser());

app.use(express.json());

app.use('/register', require('./routes/register'));
app.use('/auth', require('./routes/auth'));
app.use('/refresh', require('./routes/refresh'));
app.use('/view', require('./routes/view'));
app.use('/update', require('./routes/update'));

app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
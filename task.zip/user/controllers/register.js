const User = require('../models/user');
const bcrypt = require('bcryptjs');

const newUser = async (req, res) => {
    const { userN, email, password} = req.body;
    if (!userN || !password || !email) return res.status(400).json({ 'message': 'Username, email and password are required'});
    if (User.findOne({where: {userN: username}})) return res.sendStatus(409);
    if (User.findOne({where: {email: email}})) return res.sendStatus(409);
    
    try {
        const hashedPass = await bcrypt.hash(password, 10);
        const user = await User.create({
            userN,
            email,
            password: hashedPass
        });
        alert("Successfully registered user");
    } catch (err) {
        res.status(500).json({'message': err.message});
    }
}

module.exports = { newUser };
const User = require('../models/user');
const bcrypt = require('bcryptjs');

const login = async (req, res) => {
    const {user, password} = req.body;
    if (!user || !password) return res.status(400).json({ 'message' : 'Username or email, and password are required.'});
    const registeredUser = User.findOne({ where: {user : username} || {user : email}});
    if (!registeredUser) return res.sendStatus(401);
    const found = await bcrypt.compare(password, registeredUser.password);
    if (found) {
        res.json( {'success' : `User ${user} is logged in` });
    } else {
        res.sendStatus(401);    
    }
}

module.exports = {login};
const sequelize = require('sequelize');

const seq = new sequelize('register', 'root', 'Theoriginal13!', {
    dialect: 'mysql'
});

const User = seq.define('Users', {
    username: {
        type: sequelize.DataTypes.STRING,
        allowNull: false
    },
    password: {
        type: sequelize.DataTypes.STRING,
        allowNull: false
    },
    email: {
        type: sequelize.DataTypes.INTEGER,
        allowNull: false
    },
    role: {
        type: sequelize.DataTypes.STRING,
        defaultValue: 'Customer'
    }
});

module.exports = User;

const sequelize = require('sequelize');

const seq = new sequelize('register', 'root', 'Theoriginal13!', {
    dialect: 'mysql'
});

const OTP = seq.define('otp', {
    userID: {
        type: sequelize.DataTypes.INTEGER,
        primaryKey: true,
        allowNull: false
    },
    otp: {
        type: sequelize.DataTypes.STRING,
        allowNull: false
    },
    createdAt: {
        type: sequelize.DataTypes.DATE
    },
    expiresAt: {
        type: sequelize.DataTypes.DATE
    }
});

try {seq.sync({ force : false});}
catch(err) {console.error(err);}

module.exports = OTP;

const User = require('../models/user');
const otpMod = require('../models/otp');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

const otpVerification = async (req, res) => {
    const { otp } = req.body;

    if (!otp) return res.status(400).json({ 'message': 'OTP is required.' });

    try {

        const otpRecord = await otpMod.findOne({ where: { otp: otp } });
        if (!otpRecord) return res.status(401).json({ 'message': 'OTP not found or expired.' });

        const registeredUser = await User.findOne({ where: { id: otpRecord.userID } });
        if (!registeredUser) return res.status(401).json({ 'message': 'User not found.' });

        if (Date.now() > otpRecord.expiresAt) {
            await otpRecord.destroy();
            return res.status(401).json({ 'message': 'OTP has expired.' });
        }

        const role = registeredUser.role;
        const id = registeredUser.id;

        const accessToken = jwt.sign(
            {'email': registeredUser.email},
            process.env.ACCESS_TOKEN_SECRET,
            { expiresIn: '300s'}
        );
        
        const refreshToken = jwt.sign(
            {'email': registeredUser.email},
            process.env.REFRESH_TOKEN_SECRET,
            { expiresIn: '1d'}
        );
        
        registeredUser.refreshToken = refreshToken;
        
        await registeredUser.save();

        res.cookie('jwt', refreshToken, { httpOnly: true, secure: true, sameSite: 'None', maxAge: 24 * 60 * 60 * 1000 });

        res.json({  id, role, accessToken });    
        
    } catch(err) {
         
        res.sendStatus(401);    
    }
}

module.exports = { otpVerification };

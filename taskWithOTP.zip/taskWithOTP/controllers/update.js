const User = require('../models/user');

const update = async (req, res) => {
    const { username, em } = req.body;

    try {
        const user = await User.findOne({where : {email : req.user.email}});

        if (!user) {
            return res.status(404).json({ message: 'User not found.' });
        }

        user.username = username || user.username;
        user.email = em || user.email;

        await user.save();

        res.status(200).json({
            message: 'Profile updated successfully',
            user: {
                username: user.username,
                email: user.email
            }
        });
    } catch (error) {
        res.status(500).json({
            message: 'Error updating profile',
            error: error.message
        });
    }
};

module.exports = { update }
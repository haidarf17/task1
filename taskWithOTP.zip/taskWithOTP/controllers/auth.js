const User = require('../models/user');
const otpMod = require('../models/otp');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const nodemailer = require('nodemailer');

const login = async (req, res) => {
    const {email, password} = req.body;

    if (!email || !password) return res.status(400).json({ 'message' : 'Email and password are required.'});
    const registeredUser = await User.findOne({ where: {email : email}});
    
    if (!registeredUser) return res.sendStatus(401);
    const found = await bcrypt.compare(password, registeredUser.password);

    if (found) {
        await otpVerification(registeredUser, res);  
        
    } else {
         
        res.sendStatus(401);    
    }
}

const otpVerification = async (registeredUser, res) => {
    const otp = `${Math.floor(Math.random() * 9000)}`;
    
    let emailer = nodemailer.createTransport({
        host: "smtp.gmail.com",
        port: 587,
        secure: false,
        auth: {
            user: `${process.env.email}`,
            pass: `${process.env.pass}`
        }
    });

    const mailOptions = {
        from: `${process.env.email}`,
        to: registeredUser.email,
        subject: "Login Verification",
        text: `<p>Enter the otp <b>${otp}</b> in the app to verify your login. The otp expires in 10 minutes</p>`,
      };
    
    const id = registeredUser.id;
    const newOTP = await new otpMod({
        userID: id,
        otp: `${otp}`,
        createdAt: Date.now(),
        expiresAt: Date.now() + 600000,
    });

    await newOTP.save();

    emailer.sendMail(mailOptions, (error, info) => {
        if (error) {
          console.error("Error sending email: ", error);
        } else {
          console.log("Email sent: ", info.response);
        }
      });
    
}

module.exports = {login};
const express = require('express');
const router = express.Router();
const updateController = require('../controllers/update')
const verify = require('../middleware/verifyJWT')

router.put('/',  verify.verifyJWT, updateController.update);

module.exports = router;
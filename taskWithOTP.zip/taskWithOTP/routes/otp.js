const express = require('express');
const router = express.Router();
const otpController = require('../controllers/otpVerify')

router.post('/', otpController.otpVerification);

module.exports = router;
